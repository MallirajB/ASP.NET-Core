﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeForm.Core.Model
{
   public class Location
    {
        public int LocationId { get; set; }
        public string? WorkLocation { get; set; }
    }
}
